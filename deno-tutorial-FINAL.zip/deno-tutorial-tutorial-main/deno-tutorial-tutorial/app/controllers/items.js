import { createItem, getItems, getItem, updateItem, deleteItem } from "../models/items.js";
import render from "../render.js";
import { itemsView, editItemView } from "../views/items.js";
import redirect from "../redirect.js";

export function itemsController(ctx) {
    const { errors, request } = ctx;

    const url = new URL(request.url);
    const search = url.searchParams.get("search");

    let items = getItems();

    if (search) {
        items = items.filter(item =>
            item.label.toLowerCase().includes(search.toLowerCase())
        );
    }

    return render(itemsView, { items, errors }, ctx);
}

export function addItemController(ctx, next) {
    const { headers, isValid, validated } = ctx;
    if (!isValid) return next(ctx);
    const newItem = validated['new-item'];
    createItem(newItem);
    console.log("new item added");
    
    return redirect(headers, '/items', `added '${newItem}' to the list`)
}

export function editItemController(ctx) {
    const { request, errors } = ctx;
    const url = new URL(request.url);
    // split the url to get the id from /items/:id/edit
    const parts = url.pathname.split('/');
    const id = parts[2];

    const item = getItem(id);

    // if theres no item just redirect back
    if (!item) {
        return redirect(ctx.headers, '/items', 'item not found');
    }

    return render(editItemView, { item, errors }, ctx);
}

export function updateItemController(ctx, next) {
    const { headers, isValid, validated, request } = ctx;
    if (!isValid) return next(ctx);

    const url = new URL(request.url);
    const parts = url.pathname.split('/');
    const id = parts[2];

    const label = validated['new-item'];
    updateItem(id, label);
    console.log("item updated");

    return redirect(headers, '/items', `updated item successfully`);
}

export function deleteItemController(ctx) {
    const { headers, request } = ctx;

    const url = new URL(request.url);
    const parts = url.pathname.split('/');
    const id = parts[2];

    deleteItem(id);
    console.log("item deleted");

    return redirect(headers, '/items', 'item deleted');
}

