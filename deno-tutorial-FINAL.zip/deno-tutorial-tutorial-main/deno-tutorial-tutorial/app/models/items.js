import { db } from "../db.js";

export function getItems() { 
    return db.prepare(`SELECT * FROM items`).all();
}

export function getItem(id) {
    // get a single item by its id
    return db.prepare("SELECT * FROM items WHERE id = :id").get({ id });
}

export function createItem(newItem) {
    db.prepare("INSERT INTO items (label) VALUES (:newItem)").run({ newItem });
}

export function updateItem(id, label) {
    db.prepare("UPDATE items SET label = :label WHERE id = :id").run({ id, label });
}

export function deleteItem(id) {
    db.prepare("DELETE FROM items WHERE id = :id").run({ id });
}