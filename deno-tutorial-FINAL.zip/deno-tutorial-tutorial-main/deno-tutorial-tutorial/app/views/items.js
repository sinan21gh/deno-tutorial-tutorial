import { escape } from "@std/html/entities";
import { fragments } from "./errors.js";

export function itemsView({ items, errors = { "new-item": {} } }) {
    const newItem = fragments(errors)["new-item"];

    // map each item to a list item with edit and delete buttons
    const listItems = items.map(item => `
        <li>
            <article class="item-card">
                <p>${escape(item.label)}</p>
                <div class="item-actions">
                    <a href="/items/${item.id}/edit">edit</a>
                    <form method="POST" action="/items/${item.id}/delete">
                        <button>delete</button>
                    </form>
                </div>
            </article>
        </li>`).join("\n");

    return `
    <section aria-labelledby="items-heading">
        <h2 id="items-heading">A list of items</h2>
        <form method="POST" class="new-item" aria-label="add new item">
            <label for="new-item">New item:</label>
            <input id="new-item" name="new-item" required${newItem.value}>
            ${newItem.message}
            <button>add item</button>
        </form>
        <ul class="items-list">
        ${listItems}
        </ul>

        <form method="GET" aria-label="search items">
            <label for="search">Search:</label>
            <input id="search" name="search" placeholder="Search items">
        </form>
    </section>
    `
}

export function editItemView({ item, errors = { "new-item": {} } }) {
    const newItem = fragments(errors)["new-item"];

    return `
    <section aria-labelledby="edit-heading">
        <h2 id="edit-heading">Edit item</h2>
        <form method="POST" class="new-item">
            <label for="new-item">Item name:</label>
            <input id="new-item" name="new-item" value="${escape(item.label)}"${newItem.value} required>
            ${newItem.message}
            <button>save changes</button>
        </form>
        <a href="/items">cancel</a>
    </section>
    `
}
