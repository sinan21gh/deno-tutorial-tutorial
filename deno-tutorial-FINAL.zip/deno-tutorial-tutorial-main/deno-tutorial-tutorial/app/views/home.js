export function homeView({ session }) {

    const message = session
        ? `Welcome ${session.username}, this is your home page.`
        : "Welcome to the home page, sign in to get personalised content."

    return`
        <section aria-labelledby="home-heading">
            <h2 id="home-heading">Home page</h2>
            <p>${message}</p>
            <article>
                <h3>About this app</h3>
                <p>This application lets you manage a list of items. You can add, edit and delete items once you are signed in.</p>
                <p>Use the navigation above to get started. If you dont have an account yet you can <a href="/register">sign up here</a>.</p>
            </article>
        </section>
    `
}
