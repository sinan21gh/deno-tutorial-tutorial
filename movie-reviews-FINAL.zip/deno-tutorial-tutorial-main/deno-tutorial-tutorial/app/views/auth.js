import { fragments } from "./errors.js";

export function loginFormView({ errors = { username: {}, password: {} } }) { 
    const { username, password } = fragments(errors);
    
    return `
    <section aria-labelledby="login-heading" class="center">
        <h2 id="login-heading">Sign in to your account</h2>
        <p>Don't have an account? <a href="/register">Sign up here</a></p>
        <form method="POST" class="auth">
            <label for="username">Username</label>
            <input id="username" name="username"${username.value} required minlength="8" placeholder="Enter your username">
            ${username.message}
            <label for="password">Password</label>
            <input id="password" name="password" type="password"${password.value} required minlength="12" placeholder="Enter your password">
            ${password.message}
            <button>Sign in</button>
        </form>
    </section>
    `
}


export function registrationFormView({ errors = { username: {}, password: {} } }) {
    const { username, password } = fragments(errors);

    return `
    <section aria-labelledby="register-heading" class="center">
        <h2 id="register-heading">Create an account</h2>
        <p>Already have an account? <a href="/login">Sign in here</a></p>
        <form method="POST" class="auth">
            <label for="username">Username</label>
            <input id="username" name="username"${username.value} required minlength="8" placeholder="Choose a username">
            ${username.message}
            <label for="password">Password</label>
            <input id="password" name="password" type="password"${password.value} required minlength="12" placeholder="Choose a password">
            ${password.message}
            <label for="confirm">Confirm password</label>
            <input id="confirm" type="password" placeholder="Repeat your password">
            <button>Sign up</button>
        </form>
        <script type="module" src="/assets/js/confirmPassword.js"></script>
    </section>
    `
}
