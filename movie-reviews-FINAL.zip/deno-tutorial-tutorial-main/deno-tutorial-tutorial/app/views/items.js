import { escape } from "@std/html/entities";
import { fragments } from "./errors.js";

export function reviewsView({ reviews, errors = { "movie-title": {} } }) {
    const movieTitle = fragments(errors)["movie-title"];

    const reviewCards = reviews.map(review => `
        <li>
            <article class="item-card">
                <p>${escape(review.title)}</p>
                <div class="item-actions">
                    <a href="/reviews/${review.id}/edit">edit</a>
                    <form method="POST" action="/reviews/${review.id}/delete">
                        <button>delete</button>
                    </form>
                </div>
            </article>
        </li>`).join("\n");

    return `
    <section aria-labelledby="reviews-heading">
        <h2 id="reviews-heading">Movie Reviews</h2>

        <form method="POST" class="new-item" aria-label="add new review">
            <label for="movie-title">Movie title:</label>
            <input id="movie-title" name="movie-title" placeholder="e.g. The Dark Knight" required${movieTitle.value}>
            ${movieTitle.message}
            <button>Add review</button>
        </form>

        <ul class="items-list">
        ${reviewCards.length ? reviewCards : '<li><p>No reviews yet, add one above!</p></li>'}
        </ul>

        <form method="GET" aria-label="search reviews">
            <label for="search">Search:</label>
            <input id="search" name="search" placeholder="Search reviews...">
        </form>
    </section>
    `
}

export function editReviewView({ review, errors = { "movie-title": {} } }) {
    const movieTitle = fragments(errors)["movie-title"];

    return `
    <section aria-labelledby="edit-heading">
        <h2 id="edit-heading">Edit Review</h2>
        <form method="POST" class="new-item">
            <label for="movie-title">Movie title:</label>
            <input id="movie-title" name="movie-title" value="${escape(review.title)}"${movieTitle.value} required>
            ${movieTitle.message}
            <button>Save changes</button>
        </form>
        <a href="/reviews">cancel</a>
    </section>
    `
}
