export function homeView({ session }) {

    const message = session
        ? `Welcome back, ${session.username}.`
        : "Welcome to Movie Reviews. Sign in to start reviewing films."

    return`
        <section aria-labelledby="home-heading">
            <h2 id="home-heading">Home</h2>
            <p>${message}</p>
            <article>
                <h3>About this site</h3>
                <p>Movie Reviews is a simple app where you can keep track of films you have watched. Add a movie, edit your review or remove it whenever you like.</p>
                <p>Dont have an account yet? <a href="/register">Sign up here</a> to get started.</p>
            </article>
        </section>
    `
}
