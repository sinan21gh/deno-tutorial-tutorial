export function notFoundView() { 
    return `
        <section aria-labelledby="notfound-heading">
            <h2 id="notfound-heading">Page not found</h2>
            <p>Sorry, the page you were looking for doesnt exist.</p>
            <p><a href="/">Go back to the home page</a></p>
        </section>
    `    
}
