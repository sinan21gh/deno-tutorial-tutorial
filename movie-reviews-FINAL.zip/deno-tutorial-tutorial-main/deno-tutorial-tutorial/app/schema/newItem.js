import { required } from "../validation.js";

export const newItemSchema = {
    "movie-title": {
        validators: [required],
        displayName: "Movie title"
    }
}
