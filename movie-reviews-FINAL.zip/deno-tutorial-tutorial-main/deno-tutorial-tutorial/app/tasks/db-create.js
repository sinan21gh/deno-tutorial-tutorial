import { db } from "../db.js";

db.exec(`
    DROP TABLE IF EXISTS reviews;
    DROP TABLE IF EXISTS sessions;
    DROP TABLE IF EXISTS users;

    CREATE TABLE users (
        username TEXT PRIMARY KEY,
        hashedPassword TEXT NOT NULL
    );

    CREATE TABLE sessions (
        id TEXT PRIMARY KEY,        
        username TEXT NOT NULL,
        FOREIGN KEY (username) REFERENCES users(username)
    );

    CREATE TABLE reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL
    );

    INSERT INTO reviews (title) VALUES
        ('The Dark Knight'),
        ('Inception'),
        ('Interstellar');
`);
