import { createReview, getReviews, getReview, updateReview, deleteReview } from "../models/items.js";
import render from "../render.js";
import { reviewsView, editReviewView } from "../views/items.js";
import redirect from "../redirect.js";

export function itemsController(ctx) {
    const { errors, request } = ctx;

    const url = new URL(request.url);
    const search = url.searchParams.get("search");

    let reviews = getReviews();

    if (search) {
        reviews = reviews.filter(review =>
            review.title.toLowerCase().includes(search.toLowerCase())
        );
    }

    return render(reviewsView, { reviews, errors }, ctx);
}

export function addItemController(ctx, next) {
    const { headers, isValid, validated } = ctx;
    if (!isValid) return next(ctx);
    const title = validated['movie-title'];
    createReview(title);
    console.log("new review added");

    return redirect(headers, '/reviews', `added '${title}' to reviews`);
}

export function editItemController(ctx) {
    const { request, errors } = ctx;
    const url = new URL(request.url);
    // split the url to get the id from /reviews/:id/edit
    const parts = url.pathname.split('/');
    const id = parts[2];

    const review = getReview(id);

    // if theres no review just redirect back
    if (!review) {
        return redirect(ctx.headers, '/reviews', 'review not found');
    }

    return render(editReviewView, { review, errors }, ctx);
}

export function updateItemController(ctx, next) {
    const { headers, isValid, validated, request } = ctx;
    if (!isValid) return next(ctx);

    const url = new URL(request.url);
    const parts = url.pathname.split('/');
    const id = parts[2];

    const title = validated['movie-title'];
    updateReview(id, title);
    console.log("review updated");

    return redirect(headers, '/reviews', `review updated successfully`);
}

export function deleteItemController(ctx) {
    const { headers, request } = ctx;

    const url = new URL(request.url);
    const parts = url.pathname.split('/');
    const id = parts[2];

    deleteReview(id);
    console.log("review deleted");

    return redirect(headers, '/reviews', 'review deleted');
}
