import { db } from "../db.js";

export function getReviews() { 
    return db.prepare(`SELECT * FROM reviews`).all();
}

export function getReview(id) {
    // get a single review by its id
    return db.prepare("SELECT * FROM reviews WHERE id = :id").get({ id });
}

export function createReview(title) {
    db.prepare("INSERT INTO reviews (title) VALUES (:title)").run({ title });
}

export function updateReview(id, title) {
    db.prepare("UPDATE reviews SET title = :title WHERE id = :id").run({ id, title });
}

export function deleteReview(id) {
    db.prepare("DELETE FROM reviews WHERE id = :id").run({ id });
}
